'use strict';

require('dotenv').config({path: __dirname + '/../.env'})

const AWS = require('aws-sdk');
AWS.config.update({ region: 'eu-central-1' });
const docClient = new AWS.DynamoDB.DocumentClient();

const { dialogflow, Suggestions } = require('actions-on-google');

const app = dialogflow();

async function getLastListenExercise() {
  try {
    var params = {
        TableName: `${process.env.LIST_OF_LESSONS}`,
        Key: {
            "name": process.env.KEY
        }
    };
    const result = await docClient.get(params).promise();
    console.log("result", result)
    const textToRead = result.Item.text;
    return textToRead
  }
  catch(e) {
    console.log(e)
  }
}

app.intent('Default Welcome Intent', (conv) => {
  conv.data.example = true;
  conv.ask("You wanna read the lesson?")
  conv.ask(new Suggestions(['Read the lesson']));
});


app.intent('Reading intent', async (conv) => {
  // const text = await getLastListenExercise();
  let text;
  if(conv.data.example) {
    text = "there is example in data"
    conv.ask(text)
  } else {
    text = "there is no"
    conv.ask(text)
  }
  conv.ask(new Suggestions(['Read the lesson']));
});


module.exports = {
  app
}
